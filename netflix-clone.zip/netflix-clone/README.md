# Netflix Clone (Netflex)

Netflix-inspired streaming homepage built with HTML, CSS and vanilla JavaScript. Features a hero banner, movie cards, live title search and a click-to-open preview modal. A front-end practice project with no backend; not affiliated with Netflix.

## Features
- Sticky navigation bar with live title search
- Hero banner with Play and More Info buttons
- Movie cards rendered from a JavaScript array
- Click (or Enter/Space) on a card to open a preview modal
- "No titles found" state and responsive layout

## Tech Stack
HTML5, CSS3 (Flexbox, gradients, `<dialog>`), JavaScript (ES6)

## Run Locally
Clone the repo and open `index.html` in your browser. No build step or internet connection needed.

## Customize
Edit the `movies` array in `netflix.js` to add your own titles.

## Disclaimer
This is an educational project. It is not affiliated with or endorsed by Netflix, Inc.

## License
MIT
