const movieRows = document.getElementById("movieRows");
const searchInput = document.getElementById("searchInput");
const modal = document.getElementById("previewModal");
const modalTitle = document.getElementById("modalTitle");
const modalMeta = document.getElementById("modalMeta");

const movies = [
    { title: "Red Horizon", year: "2024" },
    { title: "Midnight Chase", year: "2023" },
    { title: "The Last Signal", year: "2022" },
    { title: "Neon City", year: "2024" }
];

function openPreview(movie) {
    modalTitle.textContent = movie.title;
    modalMeta.textContent = `${movie.year} | Now playing preview...`;
    // Re-open so the progress animation restarts every time
    if (modal.open) modal.close();
    modal.showModal();
}

function renderMovies(filter = "") {
    movieRows.innerHTML = "";

    const results = movies.filter(movie =>
        movie.title.toLowerCase().includes(filter.trim().toLowerCase())
    );

    results.forEach(movie => {
        const card = document.createElement("div");
        card.className = "movie-card";
        card.tabIndex = 0;
        card.setAttribute("role", "button");

        const title = document.createElement("h3");
        title.textContent = movie.title;
        const year = document.createElement("p");
        year.textContent = movie.year;
        card.append(title, year);

        card.addEventListener("click", () => openPreview(movie));
        card.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                openPreview(movie);
            }
        });

        movieRows.appendChild(card);
    });

    if (!results.length) {
        movieRows.textContent = "No titles found.";
    }
}

searchInput.addEventListener("input", event => {
    renderMovies(event.target.value);
});

document.getElementById("heroPlayBtn").addEventListener("click", () => {
    openPreview(movies[0]);
});
document.getElementById("heroInfoBtn").addEventListener("click", () => {
    openPreview(movies[0]);
});
document.getElementById("closeModalBtn").addEventListener("click", () => {
    modal.close();
});
// Close when clicking the dark backdrop
modal.addEventListener("click", event => {
    if (event.target === modal) modal.close();
});

renderMovies();
